﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoboticsParser
{
    class Program
    {
        static void ProcessFile_logic(string Source, string Destination, string log)
        {
            using (StreamReader streamReader = new StreamReader(Source))
            using (StreamWriter streamWriter = new StreamWriter(Destination, true))
            using (StreamWriter streamWriterLog = new StreamWriter(log, true))
            {
                try
                {
                    string line;
                    char[] arr = Source.ToCharArray();
                    Array.Reverse(arr);
                    string appendFileName = new string(arr).Substring(9, 3);
                    arr = appendFileName.ToCharArray();
                    Array.Reverse(arr);
                    appendFileName = new string(arr);
                    int records = 0;
                    if ((line = streamReader.ReadLine()) != null)
                    {
                        records = Convert.ToInt32(line);
                    }
                    if (records != 0)
                    {
                        for (int i = 0; i < records; i++)
                        {
                            String toWrite = "";
                            for (int j = 0; j < 3; j++)
                            {
                                streamReader.ReadLine();
                            }
                            for (int j = 1; j <= 19; j++)
                            {
                                switch (j)
                                {
                                    case 2:
                                    case 4:
                                    case 5:
                                    case 7:
                                    case 9:
                                    case 11:
                                    case 13:
                                    case 15:
                                    case 17:
                                    case 19:
                                        line = streamReader.ReadLine();
                                        String[] s = line.Split(' ');
                                        toWrite = toWrite + s[8] + "," + s[9] + "," + s[10] + ",";
                                        break;

                                    case 6:
                                    case 10:
                                    case 14:
                                    case 18:
                                        line = streamReader.ReadLine();
                                        s = line.Split(' ');
                                        toWrite = toWrite + s[10] + ",";
                                        break;
                                    default:
                                        streamReader.ReadLine();
                                        break;
                                }
                            }
                            for (int j = 0; j < 6; j++)
                            {
                                streamReader.ReadLine();
                            }
                            //append filename here
                            toWrite = toWrite + appendFileName;
                            streamWriter.WriteLine(toWrite);
                        }
                    }
                }
                catch (Exception e)
                {
                    string s = "The following file is corrupt :" + Source;
                    streamWriterLog.WriteLine(s);
                }
            }
        }

        static void ProcessFile_logic1(string Source, string Destination, string log, string label)
        {
            using (StreamReader streamReader = new StreamReader(Source))
            using (StreamWriter streamWriter = new StreamWriter(Destination, true))
            using (StreamWriter streamWriterLog = new StreamWriter(log, true))
            {
                try
                {
                    string line;                  
                    int records = 0;
                    if ((line = streamReader.ReadLine()) != null)
                    {
                        records = Convert.ToInt32(line);
                    }
                    if (records != 0)
                    {
                        for (int i = 0; i < records; i++)
                        {
                            String toWrite = "";
                            for (int j = 0; j < 3; j++)
                            {
                                streamReader.ReadLine();
                            }
                            for (int j = 1; j <= 19; j++)
                            {
                                switch (j)
                                {
                                    case 2:
                                    case 4:
                                    case 5:
                                    case 7:
                                    case 9:
                                    case 11:
                                    case 13:
                                    case 15:
                                    case 17:
                                    case 19:
                                        line = streamReader.ReadLine();
                                        String[] s = line.Split(' ');
                                        toWrite = toWrite + s[8] + "," + s[9] + "," + s[10] + ",";
                                        break;

                                    case 6:
                                    case 10:
                                    case 14:
                                    case 18:
                                        line = streamReader.ReadLine();
                                        s = line.Split(' ');
                                        toWrite = toWrite + s[10] + ",";
                                        break;
                                    default:
                                        streamReader.ReadLine();
                                        break;
                                }
                            }
                            for (int j = 0; j < 6; j++)
                            {
                                streamReader.ReadLine();
                            }
                            //append filename here
                            toWrite = toWrite + label;
                            streamWriter.WriteLine(toWrite);
                        }
                    }
                }
                catch (Exception e)
                {
                    string s = "The following file is corrupt :" + Source;
                    streamWriterLog.WriteLine(s);
                }
            }
        }

        static void ProcessFile_logic2(string Source, string Destination, string log, string label)
        {
            using (StreamReader streamReader = new StreamReader(Source))
            using (StreamWriter streamWriter = new StreamWriter(Destination, true))
            using (StreamWriter streamWriterLog = new StreamWriter(log, true))
            {
                try
                {
                    string line;
                    int records = 0;
                    if ((line = streamReader.ReadLine()) != null)
                    {
                        records = Convert.ToInt32(line);
                    }
                    if (records != 0 && records >=30)
                    {
                        String toWrite = "";
                        for (int i = 0; i < 30; i++)
                        {                      
                            for (int j = 0; j < 3; j++)
                            {
                                streamReader.ReadLine();
                            }
                            for (int j = 1; j <= 19; j++)
                            {
                                switch (j)
                                {
                                    case 2:
                                    case 4:
                                    case 5:
                                    case 7:
                                    case 9:
                                    case 11:
                                    case 13:
                                    case 15:
                                    case 17:
                                    case 19:
                                        line = streamReader.ReadLine();
                                        String[] s = line.Split(' ');
                                        toWrite = toWrite + s[8] + "," + s[9] + "," + s[10] + ",";
                                        break;

                                    case 6:
                                    case 10:
                                    case 14:
                                    case 18:
                                        line = streamReader.ReadLine();
                                        s = line.Split(' ');
                                        toWrite = toWrite + s[10] + ",";
                                        break;
                                    default:
                                        streamReader.ReadLine();
                                        break;
                                }
                            }
                            for (int j = 0; j < 6; j++)
                            {
                                streamReader.ReadLine();
                            }                           
                        }
                        toWrite = toWrite + label;
                        streamWriter.WriteLine(toWrite);
                    }
                }
                catch (Exception e)
                {
                    string s = "The following file is corrupt :" + Source;
                    streamWriterLog.WriteLine(s);
                }
            }
        }

        static void ProcessFile_logic3(string Source, string Destination, string log, string label)
        {
            using (StreamReader streamReader = new StreamReader(Source))
            using (StreamWriter streamWriter = new StreamWriter(Destination, true))
            using (StreamWriter streamWriterLog = new StreamWriter(log, true))
            {
                try
                {
                    string line;
                    int records = 0;
                    if ((line = streamReader.ReadLine()) != null)
                    {
                        records = Convert.ToInt32(line);
                    }
                    if (records != 0 && records >= 30)
                    {
                        int result = records / 30;
                        int skip = result - 1;
                        String toWrite = "";
                        for (int i = 0; i < 30; i++)
                        {
                            for (int j = 0; j < 3; j++)
                            {
                                streamReader.ReadLine();
                            }
                            for (int j = 1; j <= 19; j++)
                            {
                                switch (j)
                                {
                                    case 2:
                                    case 4:
                                    case 5:
                                    case 7:
                                    case 9:
                                    case 11:
                                    case 13:
                                    case 15:
                                    case 17:
                                    case 19:
                                        line = streamReader.ReadLine();
                                        String[] s = line.Split(' ');
                                        toWrite = toWrite + s[8] + "," + s[9] + "," + s[10] + ",";
                                        break;

                                    case 6:
                                    case 10:
                                    case 14:
                                    case 18:
                                        line = streamReader.ReadLine();
                                        s = line.Split(' ');
                                        toWrite = toWrite + s[10] + ",";
                                        break;
                                    default:
                                        streamReader.ReadLine();
                                        break;
                                }
                            }
                            for (int j = 0; j < 6; j++)
                            {
                                streamReader.ReadLine();
                            }
                            for(int s=0;s<skip;s++)
                            {
                                for (int t = 0; t < 28; t++)
                                {
                                    streamReader.ReadLine();
                                }
                            }
                        }
                        toWrite = toWrite + label;
                        streamWriter.WriteLine(toWrite);
                    }
                }
                catch (Exception e)
                {
                    string s = "The following file is corrupt :" + Source;
                    streamWriterLog.WriteLine(s);
                }
            }
        }

        static void new_ProcessFile_logic2(string Source, string Destination, string log, string label)
        {
            using (StreamReader streamReader = new StreamReader(Source))
            using (StreamWriter streamWriter = new StreamWriter(Destination, true))
            using (StreamWriter streamWriterLog = new StreamWriter(log, true))
            {
                try
                {
                    string line;
                    int records = 0;
                    if ((line = streamReader.ReadLine()) != null)
                    {
                        records = Convert.ToInt32(line);
                    }
                    if (records != 0 && records >= 30)
                    {
                        String toWrite = "";
                        for (int i = 0; i < 30; i++)
                        {
                            for (int j = 0; j < 3; j++)
                            {
                                streamReader.ReadLine();
                            }
                            for (int j = 1; j <= 20; j++)
                            {
                                switch (j)
                                {
                                    case 2:
                                    case 3:
                                    case 4:
                                    case 5:
                                    case 6:                                  
                                    case 8:
                                    case 9:
                                    case 10:
                                    case 12:
                                    case 13:
                                    case 14:
                                    case 16:
                                    case 17:
                                    case 18:
                                    case 20:                                 
                                        line = streamReader.ReadLine();
                                        String[] s = line.Split(' ');
                                        //toWrite = toWrite + s[8] + "," + s[9] + "," + s[10] + ",";
                                        toWrite = toWrite + s[0] + "," + s[1] + "," + s[2] + "," + s[7] + "," + s[8] + "," + s[9] + "," + s[10] + ",";
                                        break;
                                    default:
                                        streamReader.ReadLine();
                                        break;
                                }
                            }
                            for (int j = 0; j < 5; j++)
                            {
                                streamReader.ReadLine();
                            }
                        }
                        toWrite = toWrite + label;
                        streamWriter.WriteLine(toWrite);
                    }
                }
                catch (Exception e)
                {
                    string s = "The following file is corrupt :" + Source;
                    streamWriterLog.WriteLine(s);
                }
            }
        }

        static void new_ProcessFile_logic3(string Source, string Destination, string log, string label)
        {
            using (StreamReader streamReader = new StreamReader(Source))
            using (StreamWriter streamWriter = new StreamWriter(Destination, true))
            using (StreamWriter streamWriterLog = new StreamWriter(log, true))
            {
                try
                {
                    string line;
                    int records = 0;
                    if ((line = streamReader.ReadLine()) != null)
                    {
                        records = Convert.ToInt32(line);
                    }
                    if (records != 0 && records >= 30)
                    {
                        int result = records / 30;
                        int skip = result - 1;
                        String toWrite = "";
                        for (int i = 0; i < 30; i++)
                        {
                            for (int j = 0; j < 3; j++)
                            {
                                streamReader.ReadLine();
                            }
                            for (int j = 1; j <= 20; j++)
                            {
                                switch (j)
                                {
                                    case 2:
                                    case 3:
                                    case 4:
                                    case 5:
                                    case 6:
                                    case 8:
                                    case 9:
                                    case 10:
                                    case 12:
                                    case 13:
                                    case 14:
                                    case 16:
                                    case 17:
                                    case 18:
                                    case 20:
                                        line = streamReader.ReadLine();
                                        String[] s = line.Split(' ');
                                        //toWrite = toWrite + s[8] + "," + s[9] + "," + s[10] + ",";
                                        toWrite = toWrite + s[0] + "," + s[1] + "," + s[2] + "," + s[7] + "," + s[8] + "," + s[9] + "," + s[10] + ",";
                                        break;
                                    default:
                                        streamReader.ReadLine();
                                        break;
                                }
                            }
                            for (int j = 0; j < 5; j++)
                            {
                                streamReader.ReadLine();
                            }
                            for (int s = 0; s < skip; s++)
                            {
                                for (int t = 0; t < 28; t++)
                                {
                                    streamReader.ReadLine();
                                }
                            }
                        }
                        toWrite = toWrite + label;
                        streamWriter.WriteLine(toWrite);
                    }
                }
                catch (Exception e)
                {
                    string s = "The following file is corrupt :" + Source;
                    streamWriterLog.WriteLine(s);
                }
            }
        }

        static void MoveFiles(string sourceFolder, string filterFolder, string filter)
        {
            string line;
            string source;
            string destination;
            using (StreamReader streamReader = new StreamReader(filter))
            {
                while ((line = streamReader.ReadLine()) != null)
                {
                    source = sourceFolder + "\\" + line + ".skeleton";
                    destination = filterFolder + "\\" + line + ".skeleton";
                    if (File.Exists(source))
                    {
                        File.Move(source, destination);
                        //System.Console.WriteLine(source);
                        //System.Console.WriteLine(destination);
                    }
                }
            }
        }

        static void generateMorseData()
        {
            string sourceFolder = @"E:\NewDataset-20180215T115644Z-001\NewDataset";
            string top30 = @"E:\NewDataset-20180215T115644Z-001\NewDataset\Logic1_Top30\";
            string random30 = @"E:\NewDataset-20180215T115644Z-001\NewDataset\Logic2_Random30\";
            string[] files = Directory.GetFiles(sourceFolder);
            foreach (string source in files)
            {
                string label = "";
                string top30d = top30 + Path.GetFileName(source);
                string random30d = random30 + Path.GetFileName(source);
                if(source.EndsWith("HumanGrasp_300Times.txt"))
                {
                    label = "000";
                }
                else if (source.EndsWith("HumanLook_around_300Times.txt"))
                {
                    label = "001";
                }
                else if (source.EndsWith("HumanSitDown_SitActions_100Times.txt"))
                {
                    label = "002";
                }
                else if (source.EndsWith("HumanStayingIdle_200Times.txt"))
                {
                    label = "003";
                }
                else if (source.EndsWith("HumanWalking_300Times.txt"))
                {
                    label = "005";
                }
                else if (source.EndsWith("HumanWarn_robot_300Times.txt"))
                {
                    label = "004";
                }
                using (StreamReader streamReader = new StreamReader(source))
                using (StreamWriter streamWritertop30 = new StreamWriter(top30d, true))
                using (StreamWriter streamWriterrandom30 = new StreamWriter(random30d, true))
                {
                    try
                    {
                        string line;
                        List<string> lines = new List<string>();
                        int records = 0;
                        int set = 0;
                        while ((line = streamReader.ReadLine()) != null)
                        {
                            if (line == "")
                            {
                                if (set == 1)
                                {
                                    if (records != 0 && records >= 30)
                                    {
                                        String toWrite = "";
                                        for (int i = 0; i < 30; i++)
                                        {
                                            toWrite = toWrite + "," + lines[i].Replace("[", "").Replace("]", "");
                                        }
                                        toWrite = toWrite.Substring(1) + "," + label;
                                        streamWritertop30.WriteLine(toWrite);

                                        int result = records / 30;
                                        int skip = result - 1;
                                        toWrite = "";
                                        int index = 0;
                                        for (int i = 0; i < 30; i++)
                                        {
                                            toWrite = toWrite + "," + lines[index++].Replace("[", "").Replace("]", "");
                                            for (int s = 0; s < skip; s++)
                                            {
                                                index = index + 1;
                                            }
                                        }
                                        toWrite = toWrite.Substring(1) + "," + label;
                                        streamWriterrandom30.WriteLine(toWrite);

                                        set = 0;
                                        records = 0;
                                        lines.Clear();
                                    }
                                }
                            }
                            else
                            {
                                lines.Add(line);
                                set = 1;
                                records = records + 1;
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        string s = "The following file is corrupt :" + source;
                    }
                }
            }
        }

        static void Main(string[] args)
        {
            String sourceFolder = @"E:\nturgbd_skeletons\nturgb+d_skeletons";
            string filterFolder = @"E:\nturgbd_skeletons\FilteredFiles";
            string filter = @"E:\Drive\TUB\Robotics Project\TrainingData\filter.txt";
            string[] files = Directory.GetFiles(sourceFolder);
            //MoveFiles(sourceFolder, filterFolder, filter);
            String destination1 = @"E:\Drive\TUB\Robotics Project\TrainingData\Data\Logic1\RoboticsData.skeleton";
            String log1 = @"E:\Drive\TUB\Robotics Project\TrainingData\Data\Logic1\log.txt";
            String destination2 = @"E:\Drive\TUB\Robotics Project\TrainingData\Data\7\Logic2\RoboticsData.skeleton";
            String log2 = @"E:\Drive\TUB\Robotics Project\TrainingData\Data\7\Logic2\log.txt";
            String destination3 = @"E:\Drive\TUB\Robotics Project\TrainingData\Data\7\Logic3\RoboticsData.skeleton";
            String log3 = @"E:\Drive\TUB\Robotics Project\TrainingData\Data\7\Logic3\log.txt";
            
            generateMorseData();
            /*int count = 0;
            foreach (string source in files)
            {
                int process = 0;
                string label = "";
                if (source.EndsWith("006.skeleton"))
                {
                    process = 1;
                    label = "000";
                }
                else if (source.EndsWith("008.skeleton"))
                {
                    process = 1;
                    label = "001";
                }
                else if (source.EndsWith("032.skeleton"))
                {
                    process = 1;
                    label = "002";
                }
                else if (source.EndsWith("040.skeleton"))
                {
                    process = 1;
                    label = "003";
                }
                else if (source.EndsWith("046.skeleton"))
                {
                    process = 1;
                    label = "004";
                }
                if (process == 1)
                {                  
                    ProcessFile_logic1(source, destination1, log1, label);
                    ProcessFile_logic2(source, destination2, log2, label);
                    ProcessFile_logic3(source, destination3, log3, label);
                }*/
            /*foreach (string source in files)
            {
                int process = 0;
                string label = "";
                if (source.EndsWith("008.skeleton"))
                {
                    process = 1;
                    label = "000";
                }
                else if (source.EndsWith("036.skeleton"))
                {
                    process = 1;
                    label = "001";
                }
                else if (source.EndsWith("046.skeleton"))
                {
                    process = 1;
                    label = "002";
                }
                else if (source.EndsWith("006.skeleton"))
                {
                    process = 1;
                    label = "003";
                }
                else if (source.EndsWith("040.skeleton"))
                {
                    process = 1;
                    label = "004";
                }
                if (process == 1)
                {
                    //ProcessFile_logic1(source, destination1, log1, label);
                    new_ProcessFile_logic2(source, destination2, log2, label);
                    new_ProcessFile_logic3(source, destination3, log3, label);
                }
                System.Console.WriteLine((++count) + "      " + source);
        }*/
    }
    }
}